# CyberSentinel — Network Intrusion Classification

10 classes: normal, fuzzer, analysis, backdoor, dos, exploit, generic, recon, shellcode, worm.

Columns in train/validation include 20 numeric traffic features plus `label` in train and validation.

Submit:
`sample_id,predicted_class,confidence`

The hidden test has shifted feature distributions, overlap, noise, and unknown/ambiguous behavior. Do not optimize only for raw validation accuracy.
