# DefectLens — Industrial Visual Inspection

Classes: normal, scratch, dent, contamination, misalignment, missing_component.

Train and validation are labeled by folder. Submit:
`sample_id,predicted_class,confidence`

The private test deliberately changes lighting, orientation, backgrounds and defect presentation. Do not assume a single visual shortcut will generalize.
