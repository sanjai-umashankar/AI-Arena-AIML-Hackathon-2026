# CropGuard — Hidden-Shift Plant Health Classification

Classes: healthy, rust, leaf_spot, blight, mildew, mosaic.

Train/validation images are labeled by folder. Build a classifier and submit:
`sample_id,predicted_class,confidence`

Confidence must be a number from 0 to 1. The hidden test contains changed nuisance conditions and ambiguous/unknown cases.
